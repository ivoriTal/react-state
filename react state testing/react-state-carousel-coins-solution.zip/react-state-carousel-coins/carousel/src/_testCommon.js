const TEST_IMAGES = [
  {
    src: "test1.com",
    caption: "testing image 1"
  },
  {
    src: "test2.com",
    caption: "testing image 2"
  },
  {
    src: "test3.com",
    caption: "testing image 3"
  },
];

export default TEST_IMAGES